Hello,

Thank you for downloading Java Weather API by WebAlgorithm, Inc.

You have download a demo version of the API this version will allow you to fully test and user the API. 

Once you are ready please visit http://www.webalgorithm.com to purchase a license.

Thank you,
WebAlgorithm, Inc
info@webalgorithm.com